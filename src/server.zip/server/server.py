import flask
from flask import jsonify, request, session
from flask_cors import CORS
import base64
from io import BytesIO
from PIL import Image
import datetime

import manage_users as manage_users
import send_mails as send_mails
import handle_images as handle_images

app = flask.Flask(__name__)
CORS(app)

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    response = manage_users.signin_user(mail_id=email, password=password)

    return jsonify(response)

@app.route('/verify', methods=['POST'])
def verify():
    data = request.json
    email = data.get('email')

    try :
        OTP = send_mails.send_otp(email)
        print(OTP)

        if 'error' not in OTP :
            return jsonify(OTP)
    except Exception as e :
        print(e)

    return jsonify(OTP)

@app.route('/signup', methods=['POST'])
def signup():
    data = request.json
    username = data.get('username')
    email = data.get('email')
    password = data.get('password')

    response = manage_users.signup_user(username=username, mail_id=email, password=password)

    return jsonify(response)

@app.route('/generate-description', methods=['POST'])
def generate_description_endpoint():
    if 'image' not in request.files:
        return jsonify({'error': 'No image part'}), 400

    image_file = request.files['image']

    if image_file:
        img = Image.open(image_file)
        result = handle_images.main(img)
        return jsonify(result)

@app.route('/upload-image', methods=['POST'])
def upload_image():
    data = request.get_json()
    base64_image = data.get('image')
    email = data.get('email')
    file_name = data.get('filename')
    description = data.get('description')

    if not all([base64_image, email, file_name, description]):
        return jsonify({'error': 'Missing required fields'})

    try:
        image_data = base64.b64decode(base64_image)
        
        image_file = BytesIO(image_data)

        file_url = manage_users.upload_image_to_s3(image_file, email, file_name)

        image_data = {
            'file_name': file_name,
            'description': description,
            'file_url': file_url['success'],
            'favorite': False,
        }

        try:
            state = manage_users.upload_data(email, image_data)
            return jsonify(state)
        except Exception as e:
            return jsonify({'error': f'Error uploading image data: {str(e)}'})

    except Exception as e:
        return jsonify({'error': f'Error processing the image: {str(e)}'})
    
@app.route('/fetch-images', methods=['POST'])
def get_images() :
    data = request.get_json()
    email = data.get('email')

    try :
        images = manage_users.fetch_images(email)
        return jsonify(images)
    except Exception as e:
        return jsonify({'error': f'Error fetching image data: {str(e)}'})
    
@app.route('/delete-image', methods=['POST'])
def delete_image():
    data = request.get_json()
    email = data.get('email')
    file_index = data.get('file_index')

    try:
        new_stored_images = manage_users.delete_image(email, file_index)
        return jsonify(new_stored_images)
    except Exception as e:
        return jsonify({'error': f'Error deleting image data: {str(e)}'})
    
@app.route('/manage-favorites', methods=['POST'])
def manage_favorites():
    data = request.get_json()
    email = data.get('email')
    file_index = data.get('file_index')

    try:
        new_stored_images = manage_users.favorite_image(email, file_index)
        return jsonify(new_stored_images)
    except Exception as e:
        return jsonify({'error': f'Error favouriting image data: {str(e)}'})

@app.route('/update-description', methods=['POST'])
def update_description():
    data = request.get_json()
    email = data.get('email')
    file_index = data.get('file_index')
    description = data.get('description')

    try:
        new_stored_images = manage_users.update_description(email, file_index, description)
        return jsonify(new_stored_images)
    except Exception as e:
        return jsonify({'error': f'Error updating image description: {str(e)}'})

@app.route('/delete-account', methods=['POST'])
def delete_account():
    data = request.json
    email = data.get('email')

    print(email)

    try:
        response = manage_users.delete_user(email)
        print(response)
        return jsonify(response)
    except Exception as e:
        return jsonify({'error': f'Error deleting account: {str(e)}'})
    
@app.route('/change-password', methods=['POST'])
def update_password():
    data = request.json
    email = data.get('email')
    password = data.get('password')

    try:
        response = manage_users.change_password(email, password)
        return jsonify(response)
    except Exception as e:
        return jsonify({'error': f'Error updating password: {str(e)}'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)