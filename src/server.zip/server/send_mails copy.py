import smtplib
import random
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.image import MIMEImage

def generate_otp():
    return str(random.randint(100000, 999999))

def send_otp(receiver_email):
    sender_email = "magixearch@gmail.com"
    sender_password = "vuzo nxmg rkbd uitb"

    otp = generate_otp()
    otp_digits = [digit for digit in otp]
    subject = "Your OTP Code"
    
    body = f"""
    <html>
    <body>
        <h2>OTP Verification</h2>
        <p>Please enter the following OTP in the <b>magiXearch</b> portal to complete the signup.</p>
        <p>Your OTP code is :</p>
        <h1 style="background-color:#31511E; color:#F6FCDF; text-align:center; padding:1rem">
            {otp}
        </h1>
        <img src="cid:logo_image" alt="Image Description">
        <p style="color: gray; font-size: 12px; width:auto; text-align:center">This is an automated message, do not reply.</p>
    </body>
    </html>
    """
    
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = receiver_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'html'))

    with open("src/assets/magiXearch.jpg", 'rb') as img_file:
        img = MIMEImage(img_file.read())
        img.add_header('Content-Disposition', 'inline', filename="magiXearch.jpg")
        img.add_header('Content-ID', '<logo_image>')
        msg.attach(img)

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, msg.as_string())
        server.quit()
        print("OTP sent successfully!")
        return otp
    except Exception as e:
        print(f"Failed to send email: {e}")
        return {'error': str(e) }