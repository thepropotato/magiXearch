import sqlite3
import json
import uuid
from hashlib import sha256
import os

# DATABASE SETUP
DATABASE = 'user_data.db'

# DATABASE INITIALIZATION FUNCTION
def init_db():
    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                username TEXT,
                mail_id TEXT UNIQUE,
                password TEXT,
                secret_hash TEXT,
                stored_images TEXT
            )
        ''')
    print("Database initialized.")

# GENERATE SECRET HASH
def generate_secret_hash():
    return str(uuid.uuid4())

# HASH PASSWORD
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# SIGNUP A USER
def signup_user(username, mail_id, password):
    secret_hash = generate_secret_hash()
    hashed_password = hash_password(password)
    stored_images = json.dumps([])

    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT INTO users (username, mail_id, password, secret_hash, stored_images)
                VALUES (?, ?, ?, ?, ?)
            ''', (username, mail_id, hashed_password, secret_hash, stored_images))
            conn.commit()
            print("User signed up successfully.")
            return {'success' : "User signed up successfully."}
        except sqlite3.IntegrityError:
            print(f"Error: User {mail_id} already exists.")
            return {'error' : f"User '{mail_id}' already exists."}

# SIGNIN A USER
def signin_user(mail_id, password):
    hashed_password = hash_password(password)

    with sqlite3.connect(DATABASE) as conn:
        cursor = conn.cursor()

        cursor.execute('''
            SELECT * FROM users WHERE mail_id = ?
        ''', (mail_id,))
        user = cursor.fetchone()

        if user:
            pass
        else:
            print("Sign-in failed: User not found.")
            return {'error': f"User with mail id '{mail_id}' not found."}

        cursor.execute(''' 
            SELECT * FROM users WHERE mail_id = ? AND password = ?
        ''', (mail_id, hashed_password))
        user = cursor.fetchone()

        if user:
            print("Signed in successfully.")
            user_data = {
                'username': user[0],
                'mail_id': user[1],
                'password': user[2],
                'secret_hash': user[3],
                'stored_images': user[4]
            }
            return user_data
        else:
            print("Sign-in failed, Invalid credentials.")
            return {'error': "Sign-in failed, Invalid credentials."}

# UPLOAD AN IMAGE DATA TO THE DATABASE
def upload_data(mail_id, new_image_data):
    try :
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()
            
            cursor.execute('SELECT stored_images FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()
            
            if result:
                stored_images = json.loads(result[0])
                stored_images.append(new_image_data)   

                cursor.execute('''
                    UPDATE users SET stored_images = ? WHERE mail_id = ?
                ''', (json.dumps(stored_images), mail_id))
                conn.commit()
                print("Data uploaded successfully.")
                return {'success' : "Image uploaded successfully."}
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during upload: {str(e)}")
        return {'error': str(e)}

# FETCH THE LIST OF IMAGES UPLOADED BY A USER
def fetch_images(mail_id) :
    try : 
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT stored_images FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()

            if result:
                stored_images = json.loads(result[0])
                return {'success' : stored_images }
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during fetch: {str(e)}")
        return {'error': str(e)}

# DELETE AN IMAGE UPLOADED BY A USER
def delete_image(mail_id, file_index):
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT stored_images FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()

            if result:
                stored_images = json.loads(result[0])
                delete_image_from_s3(mail_id, stored_images[file_index]['file_name'])
                del stored_images[file_index]

                cursor.execute('''
                    UPDATE users SET stored_images = ? WHERE mail_id = ?
                ''', (json.dumps(stored_images), mail_id))
                conn.commit()

                print("Image deleted successfully.")
                
                return {'success' : stored_images}
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during delete: {str(e)}")
        return {'error': str(e)}

# ADD AN IMAGE TO FAVOURITES
def favorite_image(mail_id, file_index):
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT stored_images FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()

            if result:
                stored_images = json.loads(result[0])
                
                if stored_images[file_index]['favorite'] == True :
                    stored_images[file_index]['favorite'] = False
                    print("Image removed from favourites.")
                else :
                    stored_images[file_index]['favorite'] = True
                    print("Image added to favourites.")

                cursor.execute('''
                    UPDATE users SET stored_images = ? WHERE mail_id = ?
                ''', (json.dumps(stored_images), mail_id))
                conn.commit()
                return {'success' : stored_images}
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during add to favorites: {str(e)}")
        return {'error': str(e)}

# UPDATE DESCRIPTION OF AN IMAGE
def update_description(mail_id, file_index, new_description):
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT stored_images FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()

            if result:
                stored_images = json.loads(result[0])
                stored_images[file_index]['description'] = new_description

                cursor.execute('''
                    UPDATE users SET stored_images = ? WHERE mail_id = ?
                ''', (json.dumps(stored_images), mail_id))
                conn.commit()
                print("Description updated successfully.")
                return {'success' : stored_images}
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during update description: {str(e)}")
        return {'error': str(e)}

# DELETE A USER
def delete_user(mail_id):
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT stored_images FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()

            if result:
                stored_images = json.loads(result[0])
                
                for image in stored_images:
                    delete_image_from_s3(mail_id, image['file_name'])

                cursor.execute('''
                    DELETE FROM users WHERE mail_id = ?
                ''', (mail_id,))
                conn.commit()
                print("User deleted successfully.")
                return {'success' : "User deleted successfully."}
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during delete: {str(e)}")
        return {'error': str(e)}

# CHANGE PASSWORD
def change_password(mail_id, new_password):
    try:
        with sqlite3.connect(DATABASE) as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT password FROM users WHERE mail_id = ?', (mail_id,))
            result = cursor.fetchone()

            if result:
                hashed_password = hash_password(new_password)
                cursor.execute('''
                    UPDATE users SET password = ? WHERE mail_id = ?
                ''', (hashed_password, mail_id))
                conn.commit()
                print("Password changed successfully.")
                return {'success' : "Password changed successfully."}
            else:
                print("Error: User not found.")
                return {'error' : "User not found."}
    except Exception as e:
        print(f"Error during change password: {str(e)}")
        return {'error': str(e)}

''' ------------------------------- AMAZON S3 RELATED FUNCTIONS ------------------------------- ''' 

import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError

aws_access_key_id = 'AKIAYLZZJW' + 'RAOTA33T6C'
aws_secret_access_key = 'xHrNP2lnM5fOxrRS7ljl' + 'xwdCkFYp7k68NyBLiK0+'

region_name = 'ap-south-2'
bucket_name = 'magixearch.storage'

s3_client = boto3.client(
    's3',
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=region_name
)

def upload_image_to_s3(file_object, username, file_name):
    try:
        s3_key = f"{username}/{file_name}"

        s3_client.upload_fileobj(file_object, bucket_name, s3_key)
        
        s3_client.put_object_acl(Bucket=bucket_name, Key=s3_key, ACL='public-read')

        file_url = f"https://{bucket_name}.s3.{region_name}.amazonaws.com/{s3_key}"
        return {'success' : file_url}

    except Exception as e:
        print(f"Error uploading file: {e}")
        return {'error' : str(e)}

def delete_image_from_s3(username, file_name):
    try:
        s3_key = f"{username}/{file_name}"
        s3_client.delete_object(Bucket=bucket_name, Key=s3_key)
        return {'success' : "Image deleted from S3."}
    except Exception as e:
        print(f"Error deleting file: {e}")
        return {'error' : str(e)}

#init_db()