from PIL import Image
import google.generativeai as genai
from google.oauth2 import service_account
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from googleapiclient.http import MediaIoBaseUpload
import os

API_KEY = 'AIzaSyDF1oOU' + 'EDbyH6AXcmuNN' + 'GKkp5CkHsaMbL8'
genai.configure(api_key=API_KEY)
DRIVE_ID = '1PbTgBi25hSbhahWofFsdjcwFmynIS9xI'
CREDENTIALS_PATH = 'src\server\magiXearch-gc.json'

creds = service_account.Credentials.from_service_account_file(CREDENTIALS_PATH, scopes=["https://www.googleapis.com/auth/drive"])
service = build('drive', 'v3', credentials=creds)

def main(img):
    try :
        model = genai.GenerativeModel('gemini-1.5-flash')

        response = model.generate_content(["Please generate a description for the following image. The description should capture all the key information present in the image. Kindly refrain from using statements like 'Here's a description of the image' and such. The output should contain only the description and nothing else. Also, dont spend too much time analysing the image.", img], stream=True,
                        generation_config=genai.types.GenerationConfig(temperature=0.8))

        response.resolve()

        print(response.text)
        return {'success' : response.text}
    except Exception as e :
        print(e)
        return {'error' : str(e)}